﻿using System.ComponentModel.DataAnnotations;

namespace PasswordGenerator.Models
{
    public class PasswordGeneratorModel
    {
        [Required(ErrorMessage = "Please enter password length")]
        [Range(6, 100, ErrorMessage = "Password length must be between 6 and 100")]
        public int Length { get; set; }

        public bool IncludeUppercase { get; set; }

        public bool IncludeLowercase { get; set; }

        public bool IncludeNumbers { get; set; }

        public bool IncludeSpecialCharacters { get; set; }

        public string GeneratedPassword { get; set; }

        public PasswordGeneratorModel()
        {
            GeneratedPassword = string.Empty; // Inicializar la propiedad GeneratedPassword
        }
    }
}
