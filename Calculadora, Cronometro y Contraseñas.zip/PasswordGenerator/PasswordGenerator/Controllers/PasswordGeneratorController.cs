﻿using Microsoft.AspNetCore.Mvc;
using PasswordGenerator.Models;

namespace PasswordGenerator.Controllers
{
    public class PasswordGeneratorController : Controller
    {
        public IActionResult Index()
        {
            var model = new PasswordGeneratorModel();
            return View(model);
        }

        [HttpPost]
        public IActionResult Generate(PasswordGeneratorModel model)
        {
            if (ModelState.IsValid)
            {
                string password = GeneratePassword(model);
                model.GeneratedPassword = password;
            }
            return View("Index", model);
        }

        private string GeneratePassword(PasswordGeneratorModel model)
        {
            string uppercaseChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
            string lowercaseChars = "abcdefghijklmnopqrstuvwxyz";
            string numberChars = "0123456789";
            string specialChars = "!@#$%^&*()_-+=<>?";

            string validChars = "";
            if (model.IncludeUppercase)
                validChars += uppercaseChars;
            if (model.IncludeLowercase)
                validChars += lowercaseChars;
            if (model.IncludeNumbers)
                validChars += numberChars;
            if (model.IncludeSpecialCharacters)
                validChars += specialChars;

            string password = "";
            for (int i = 0; i < model.Length; i++)
            {
                password += validChars[new System.Random().Next(validChars.Length)];
            }
            return password;
        }
    }
}
