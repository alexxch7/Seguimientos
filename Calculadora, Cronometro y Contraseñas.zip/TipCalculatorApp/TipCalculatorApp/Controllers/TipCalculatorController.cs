﻿using Microsoft.AspNetCore.Mvc;
using TipCalculatorApp.Models;

namespace TipCalculatorApp.Controllers
{
    public class TipCalculatorController : Controller
    {
        public IActionResult Index()
        {
            return View(new TipCalculator());
        }

        [HttpPost]
        public IActionResult Calculate(TipCalculator model)
        {
            if (ModelState.IsValid)
            {
                model.TipAmount = model.BillAmount * model.TipPercentage / 100;
                model.TotalAmount = model.BillAmount + model.TipAmount;
            }
            return View("Index", model);
        }
    }
}
