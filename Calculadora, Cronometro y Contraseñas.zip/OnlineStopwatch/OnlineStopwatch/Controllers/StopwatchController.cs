﻿using Microsoft.AspNetCore.Mvc;
using OnlineStopwatch.Models;
using System.Diagnostics;

namespace OnlineStopwatch.Controllers
{
    public class StopwatchController : Controller
    {

        public IActionResult Index()
        {

            var model = new StopwatchModel();
            return View(model);
        }


        [HttpPost]
        public IActionResult Start()
        {

            return RedirectToAction("Index");
        }


        [HttpPost]
        public IActionResult Pause()
        {

            return RedirectToAction("Index");
        }


        [HttpPost]
        public IActionResult Reset()
        {

            return RedirectToAction("Index");
        }


        [HttpPost]
        public IActionResult Lap()
        {
            return RedirectToAction("Index");
        }
    }
}
