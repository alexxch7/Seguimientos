﻿namespace OnlineStopwatch.Models
{
    public class StopwatchModel
    {
  
        public TimeSpan ElapsedTime { get; set; }

        public bool IsRunning { get; set; }

        public List<TimeSpan> LapTimes { get; set; } = new List<TimeSpan>();
    }
}
